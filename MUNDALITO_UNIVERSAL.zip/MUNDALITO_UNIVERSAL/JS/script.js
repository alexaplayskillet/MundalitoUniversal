
/*abrir el menu de accesibilidad */
const Access = document.getElementById("Acc1");
const Acceso = document.querySelector(".activo");

Access.addEventListener("click", () =>{
  Acceso.classList.toggle("active");
});


/*modo oscuro */
const darkMode = document.querySelector(".DARK-MODE");
const body = document.body;

darkMode.addEventListener("click", ()=>{
    body.classList.toggle("active");
});

//activar con el enter el modo oscuro
document.querySelector(".DARK-MODE").addEventListener("keydown", (e)=>{
  if (e.key === "Enter"){
    body.classList.toggle("active");
  }
});



/*menu hamburguesa */
const toggleBtn = document.getElementById("toggleMenu");
const menu = document.querySelector(".menu");
const bodyContainer = document.querySelector(".body");

toggleBtn.addEventListener("click", () => {
  menu.classList.toggle("active");
  bodyContainer.classList.toggle("menu-active");
});


/*menu de usuario */

document.addEventListener("DOMContentLoaded", () => {
  const profileTriggers = document.querySelectorAll(".profile");
  const menu2 = document.querySelector(".menu2");

  profileTriggers.forEach(trigger => {
    trigger.addEventListener("click", (e) => {
      e.stopPropagation(); // evita que el clic cierre el menú inmediatamente
      menu2.classList.toggle("active");
    });
  });

  document.addEventListener("click", (e) => {
    const isClickInside = e.target.closest(".menu2") || e.target.closest(".profile");
    if (!isClickInside && menu2.classList.contains("active")) {
      menu2.classList.remove("active");
    }
  });
});

/*cambio del tamaño de letra*/
const getFontSize = () =>
  parseFloat(getComputedStyle(document.documentElement)
    .getPropertyValue('--font-size'))

const fontUp = element => {
  element.addEventListener('click', () => {
    let fontSize = getFontSize()
    document.documentElement
      .style.setProperty('--font-size', `${fontSize * 1.1}`)
  })
}

const fontDown = element => {
  element.addEventListener('click', () => {
    let fontSize = getFontSize()
    document.documentElement
      .style.setProperty('--font-size', `${fontSize * 0.9}`)
  })
};

addEventListener('keyup', e => {
  if(e.key === 'ArrowUp' || e.key === '+') document.getElementById('font-up').click()
  if(e.key === 'ArrowDown' || e.key === '-') document.getElementById('font-down').click()
});

fontUp(document.getElementById('font-up'));
fontDown(document.getElementById('font-down'));

//hacer el dislexia friendly

const toggleFontButton = document.getElementById('Dislexia');

const getFontFamily = () =>
  getComputedStyle(document.documentElement)
    .getPropertyValue('--font-family').trim();

toggleFontButton.addEventListener('click', () => {
  const currentFont = getFontFamily();
  const newFont = currentFont.includes('Poppins')
    ? "'Comic Neue', sans-serif"
    : "'Poppins', sans-serif";

  document.documentElement.style.setProperty('--font-family', newFont);
});

/*Navegar con teclado*/
addEventListener('keydown', d=>{
  const target = d.target;
  const isTyping = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;

  if (isTyping) return; 

  if(d.key === "S" ||d.key === "s" ){
      window.scrollBy({
      top: 100, // cantidad de píxeles a deslizar
      left: 0,
      behavior: "smooth"
    });
  }

  if (d.key === "w" || d.key === "W") {
    window.scrollBy({
      top: -100, // cantidad de píxeles hacia arriba
      left: 0,
      behavior: "smooth"
    });
  }
});